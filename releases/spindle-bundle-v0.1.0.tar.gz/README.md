# spindle-bundle — Spindle deployment bundle

Ready-to-run bundle for the Spindle integration target (Ubuntu 24.04,
PostgreSQL 16). Includes both daemons and their configuration.

## Contents

```
bin/
  spindle-server    HTTP API + ingest daemon (release)
  spindle-worker    pipeline worker daemon (release; dequeue/process/recovery)
etc/
  config.toml           server config (matches /etc/spindle/config.toml)
  spindle-worker.env    worker env overrides (DATABASE_URL)
  spindle.toml.example  shared CLI/server template (SPINDLE_CONFIG)
systemd/
  spindle-server.service   server systemd unit
  spindle-worker.service   worker systemd unit
README.md
```

## Install

```bash
sudo tar -xzf spindle-bundle.tar.gz -C /opt/spindle   # or /opt
sudo install -m 0755 bin/spindle-server /opt/spindle/bin/
sudo install -m 0755 bin/spindle-worker /opt/spindle/bin/
sudo install -m 0640 etc/config.toml /etc/spindle/config.toml
sudo install -m 0640 etc/spindle-worker.env /etc/spindle/spindle-worker.env
sudo install -m 0644 systemd/spindle-server.service /etc/systemd/system/
sudo install -m 0644 systemd/spindle-worker.service /etc/systemd/system/
sudo mkdir -p /var/lib/spindle/archive /var/lib/spindle/tmp
sudo systemctl daemon-reload
sudo systemctl enable --now spindle-server
sudo systemctl enable --now spindle-worker
```

## Environment contract

- **spindle-server**: reads `/etc/spindle/config.toml` (SPINDLE_CONFIG),
  `SPINDLE_DATABASE_URL`, `SPINDLE_ARCHIVE_DIR`, `SPINDLE_INGEST_TOKEN`.
- **spindle-worker**: env-only — `SPINDLE_DATABASE_URL`, `SPINDLE_ARCHIVE_DIR`,
  `SPINDLE_WORKER_POLL_INTERVAL` (s), `SPINDLE_WORKER_CLAIM_TIMEOUT` (s).
  These are provided via `/etc/spindle/spindle-worker.env` and the systemd unit.

Both daemons run as user `spindle`; the archive dir must be writable by that user.

## Verification

```bash
systemctl status spindle-server spindle-worker
curl -s http://127.0.0.1:8080/health
```

Built from Spindle git main @ `4da5687` (Task 6 bundle), extended with migration 029
(aligned `jobs.node_name` + `pipeline_dead_letter`) so the bundled worker daemon
can dequeue without DB errors.

## Schema prerequisites

The live DB must be at migration 029 for both daemons to run cleanly. The
validated migration set lives in the repo's `/tmp/mig-workspace` workdir and is
applied via `sqlx migrate run --source /tmp/mig-workspace`. Worker dequeue
requires migration 029 (`jobs.node_name`, `pipeline_dead_letter`); read/store
requires 028 (UUID nodes/runs/resource_events schema).